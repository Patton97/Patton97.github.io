A collection of game assets to use when playing with the game engine.
Many spaceship images come from http://millionthvector.blogspot.com/
Sound files come from various online free sources. If you plan to release a game,
you should acknowledge the source of all assets or make your own.