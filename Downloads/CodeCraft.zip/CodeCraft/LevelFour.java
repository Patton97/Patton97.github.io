/*** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * ***
 *** * * * * * * * * LEVEL FOUR: Dead End  * * * * * * * * * * * * * * * * * ***
 *** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * ***
 *                                                                             *
 * Turns out this cave isn't so wonderful, after-all. Let's head back outside. *
 *                                                                             *
 * Now that we've seen the full cave, we know where the rocks are and how many *
 * steps to take to get out. Let's try a different type of loop, called "FOR". *
 *                                                                             * 
 * Step 1: Write a for loop to move down the required number of steps          *
 * Step 2: Write another for loop to move left, and out of the cave.           *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
 
public class LevelFour extends Rover
{   
    public void main()
    {
        
    }
}