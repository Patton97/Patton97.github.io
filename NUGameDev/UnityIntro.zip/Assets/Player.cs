﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField] float speed = 1.0f;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        Vector3 movementVector = new Vector3(0, 0, 0);

        //This section might look different to the slides - that's fine!
        //I've just tidied mine up a bit to show a different way of formatting things
        if (Input.GetKey(KeyCode.W)) { movementVector.z =  speed; }
        if (Input.GetKey(KeyCode.S)) { movementVector.z = -speed; }
        if (Input.GetKey(KeyCode.A)) { movementVector.x = -speed; }
        if (Input.GetKey(KeyCode.D)) { movementVector.x =  speed; }

        gameObject.transform.position += movementVector * Time.deltaTime;
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.GetComponent<NPC>())
        {
            collision.gameObject.GetComponent<NPC>().RemoveHealth();
        }
    }
}
